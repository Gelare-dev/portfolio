﻿
Partial Class Add_image
    Inherits System.Web.UI.Page

End Class
